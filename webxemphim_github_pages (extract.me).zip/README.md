# Web Xem Phim (GitHub Pages) - Demo

This is a minimal React + Vite app that demonstrates:
- Creating/joining rooms
- Shared video playback sync via Firebase Realtime Database
- Simple voice chat using WebRTC with signaling through Firebase Realtime Database

## Steps to use

1. Create a Firebase project:
   - Go to https://console.firebase.google.com/
   - Create a new project.
   - Add a Web App and copy the config (apiKey, authDomain, databaseURL, ...).
   - In Realtime Database, create a database in test mode (or set rules appropriately).

2. In this project, duplicate `src/firebaseConfig.example.js` and rename to `src/firebaseConfig.js`.
   Paste your Firebase config object into it, exported as default.

3. Install and run locally:
   ```bash
   npm install
   npm run dev
   ```
   Open the provided URL.

4. To publish on GitHub Pages:
   - Push this repository to GitHub.
   - Create a GitHub Actions workflow to build and publish (example provided in .github/workflows).
   - Or build locally (`npm run build`) and push the `dist` contents to `gh-pages` branch, then enable Pages.

## Notes
- This is a demo scaffold. For production you'll want to secure your Firebase rules and handle peer cleanup, reconnection, and user identities.
- The app uses Firebase Realtime Database as a simple signaling server. It writes signaling messages under `/signals/{roomId}` and playback sync under `/sync/{roomId}`.

If you want, I can:
- Create the GitHub repo and push the code (I can't do that from here, but I can give exact commands).
- Provide the GitHub Actions workflow file to auto-deploy to Pages.

Tell me if you want the auto-deploy workflow included and I'll add it.
