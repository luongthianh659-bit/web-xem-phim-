
import React, { useEffect, useRef, useState } from 'react';
import { initializeApp } from "firebase/app";
import { getDatabase, ref, push, set, onChildAdded, remove, onValue } from "firebase/database";
import firebaseConfig from './firebaseConfig.js'; // user must create this file from example

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

function makeId(n=6){
  const s="abcdefghijklmnopqrstuvwxyz0123456789";
  let r="";
  for(let i=0;i<n;i++) r+=s[Math.floor(Math.random()*s.length)];
  return r;
}

export default function App(){
  const [roomId, setRoomId] = useState('');
  const [joined, setJoined] = useState(false);
  const [rooms, setRooms] = useState([]);
  const [localStream, setLocalStream] = useState(null);
  const peersRef = useRef({});
  const audioEls = useRef({});
  const videoRef = useRef(null);

  useEffect(()=> {
    // list rooms (simple: read '/rooms' keys)
    const roomsRef = ref(db, 'rooms');
    onValue(roomsRef, (snap)=>{
      const v = snap.val() || {};
      setRooms(Object.keys(v));
    });
  },[]);

  async function createOrJoin(r){
    const id = r || makeId(6);
    setRoomId(id);
    setJoined(true);
    // create room node if not exists
    const roomRef = ref(db, `rooms/${id}`);
    set(roomRef, { createdAt: Date.now() });
    // listen for signalling messages
    const signalsRef = ref(db, `signals/${id}`);
    onChildAdded(signalsRef, (snap)=>{
      const msg = snap.val();
      handleSignal(msg, snap.key, id);
    });
    // listen for sync messages to control player
    const syncRef = ref(db, `sync/${id}`);
    onChildAdded(syncRef, (snap)=>{
      const msg = snap.val();
      if(msg && msg.type==='play'){
        if(videoRef.current){
          videoRef.current.currentTime = msg.time || 0;
          videoRef.current.play();
        }
      }
      if(msg && msg.type==='pause'){
        if(videoRef.current) videoRef.current.pause();
      }
      if(msg && msg.type==='seek'){
        if(videoRef.current) videoRef.current.currentTime = msg.time || 0;
      }
    });
    // request mic
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      setLocalStream(s);
    } catch(e){
      console.warn('mic denied', e);
    }
  }

  async function broadcast(type, payload){
    if(!roomId) return;
    const nref = push(ref(db, `sync/${roomId}`));
    await set(nref, { type, ...payload, ts: Date.now() });
  }

  // Basic signaling handling using Realtime DB
  async function sendSignal(roomId, data){
    const n = push(ref(db, `signals/${roomId}`));
    await set(n, data);
  }

  async function handleSignal(msg, key, roomIdLocal){
    // msg structure: {from, to, kind, sdp/candidate}
    if(!msg) return;
    const me = 'client-' + Math.random().toString(36).slice(2,9);
    if(msg.to && msg.to !== me && msg.to !== 'all') return;
    if(msg.kind === 'offer'){
      // create peer, set remote desc, add tracks, create answer
      const pc = new RTCPeerConnection();
      peersRef.current[msg.from] = pc;
      if(localStream) localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
      pc.ontrack = (e) => {
        const [s] = e.streams;
        const id = msg.from;
        let audio = audioEls.current[id];
        if(!audio){
          audio = document.createElement('audio');
          audio.autoplay = true;
          audioEls.current[id] = audio;
          document.body.appendChild(audio);
        }
        audio.srcObject = s;
      };
      pc.onicecandidate = (ev) => {
        if(ev.candidate){
          sendSignal(roomIdLocal, { from: me, to: msg.from, kind: 'ice', candidate: ev.candidate });
        }
      };
      await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal(roomIdLocal, { from: me, to: msg.from, kind: 'answer', sdp: answer });
    } else if(msg.kind === 'answer'){
      const pc = peersRef.current[msg.from];
      if(pc) pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
    } else if(msg.kind === 'ice'){
      const pc = peersRef.current[msg.from];
      if(pc) pc.addIceCandidate(new RTCIceCandidate(msg.candidate));
    } else if(msg.kind === 'new-peer'){
      // someone new joined; create offer to them
      const target = msg.from;
      const me2 = 'client-' + Math.random().toString(36).slice(2,9);
      if(!localStream) return;
      const pc = new RTCPeerConnection();
      peersRef.current[target] = pc;
      localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
      pc.ontrack = (e) => {
        const [s] = e.streams;
        let audio = audioEls.current[target];
        if(!audio){
          audio = document.createElement('audio'); audio.autoplay = true;
          audioEls.current[target] = audio; document.body.appendChild(audio);
        }
        audio.srcObject = s;
      };
      pc.onicecandidate = (ev) => {
        if(ev.candidate){
          sendSignal(roomIdLocal, { from: me2, to: target, kind:'ice', candidate: ev.candidate });
        }
      };
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      sendSignal(roomIdLocal, { from: me2, to: target, kind:'offer', sdp: offer });
    }
  }

  async function announcePresence(){
    if(!roomId) return;
    const me = 'client-' + Math.random().toString(36).slice(2,9);
    const n = push(ref(db, `signals/${roomId}`));
    set(n, { from: me, to: 'all', kind:'new-peer' });
  }

  return (
    <div className="container">
      <div className="header">
        <h1>Web Xem Phim - Phòng &amp; Mic (GitHub Pages)</h1>
        <div><small>Free • Firebase signaling</small></div>
      </div>

      <div className="card">
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <input placeholder="ID phòng (để trống sẽ tạo mới)" value={roomId} onChange={e=>setRoomId(e.target.value)} />
          <button className="button" onClick={()=>createOrJoin(roomId)}>Tạo / Vào phòng</button>
          {joined && <button className="button" onClick={announcePresence}>Thông báo presence</button>}
        </div>
        <div style={{marginTop:8}}><small>Gợi ý: chia sẻ ID phòng cho bạn bè.</small></div>
      </div>

      <div className="card">
        <h3>Trình phát video</h3>
        <video ref={videoRef} controls onPlay={()=>broadcast('play',{time:videoRef.current?.currentTime})} onPause={()=>broadcast('pause')} onSeeked={()=>broadcast('seek',{time:videoRef.current?.currentTime})}>
          <source src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" type="video/mp4"/>
        </video>
        <div style={{marginTop:8}}>
          <button className="button" onClick={()=>{ if(videoRef.current){ videoRef.current.play(); broadcast('play',{time:videoRef.current.currentTime}); }}}>Phát</button>
          <button className="button" onClick={()=>{ if(videoRef.current){ videoRef.current.pause(); broadcast('pause'); }}}>Tạm dừng</button>
          <button className="button" onClick={()=>{ if(videoRef.current){ videoRef.current.currentTime=0; broadcast('seek',{time:0}); }}}>Về đầu</button>
        </div>
      </div>

      <div className="card">
        <h3>Mic</h3>
        <div>
          {!localStream ? <small>Mic chưa bật — bấm Tạo/Vào phòng để cấp quyền mic.</small> : <small>Mic đã sẵn sàng.</small>}
        </div>
      </div>

      <div className="card">
        <h3>Phòng có sẵn</h3>
        <div className="room-list">
          {rooms.length===0 && <small>Không có phòng</small>}
          {rooms.map(r => <div key={r}><span>{r}</span> <button onClick={()=>createOrJoin(r)}>Vào</button></div>)}
        </div>
      </div>

      <div style={{marginTop:20}}><small>Hướng dẫn nhanh: tạo Firebase project → tạo Realtime Database → copy cấu hình vào src/firebaseConfig.js (theo file example).</small></div>
    </div>
  );
}
