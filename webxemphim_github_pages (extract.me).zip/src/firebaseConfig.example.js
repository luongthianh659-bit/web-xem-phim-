// Rename this file to firebaseConfig.js and paste your Firebase config object.
// How to get config:
// 1. Go to https://console.firebase.google.com/ -> Create Project
// 2. Add a Web App and copy the config values
// 3. Paste the config below as default export
export default {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  databaseURL: "YOUR_DATABASE_URL",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
}
